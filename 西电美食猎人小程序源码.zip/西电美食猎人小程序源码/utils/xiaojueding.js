module.exports = [
   {
      id: 0,
      option: '真心话大冒险',
      awards: [
         {
            name: "描述经历过最尴尬的事",
            color: '#EE534F'
         },
         {
            name: "今天穿什么颜色的内裤",
            color: '#DA70D6'
         },
         {
            name: "第一次接吻几岁",
            color: '#FFA827'
         },
         {
            name: "做过最疯狂的事是什么",
            color: '#5C6BC0'
         },
         {
            name: "单身的感觉好吗",
            color: '#42A5F6'
         },
         
         {
            name: "和前任还有联系吗",
            color: '#FFC928'
         },
         {
            name: "上一次接吻是什么时候",
            color: '#AA47BC'
         },
         
         {
            name: "多久没看书了",
            color: '#FF7F50'
         }
      ]
   },

   {
      id: 1,
      option: '抽取狼人杀身份牌',
      awards: [
         {
            index: 0,
            name: "预言家",
            color: '#EE534F'
         },
         {
            index: 1,
            name: "狼人",
            color: '#FF7F50'
         },
         {
            index: 2,
            name: "村民",
            color: '#FFC928'
         },
         {
            index: 3,
            name: "狼人",
            color: '#66BB6A'
         },
         {
            index: 4,
            name: "村民",
            color: '#42A5F6'
         },
         {
            index: 5,
            name: "狼人",
            color: '#AA47BC'
         },
         {
            index: 6,
            name: "村民",
            color: '#EC407A'
         },
         {
            index: 7,
            name: "狼人",
            color: '#EE534F'
         },
         {
            index: 8,
            name: "村民",
            color: '#FFC928'
         },
         {
            index: 9,
            name: "猎人",
            color: '#66BB6A'
         },
         {
            index: 10,
            name: "女巫",
            color: '#42A5F6'
         },
         {
            index: 11,
            name: "丘比特",
            color: '#5C6BC0'
         },
         {
            index: 12,
            name: "白痴",
            color: '#FFC928'
         }
      ]
   },
   
   {
      id: 2,
      option: '十一国庆去哪玩',
      awards: [
         {
            name: "凤凰古城",
            color: '#EE534F'
         },
         {
            name: "张家界",
            color: '#FF7F50'
         },
         {
            name: "乌镇",
            color: '#FFC928'
         },
         {
            name: "鼓浪屿",
            color: '#66BB6A'
         },
         {
            name: "千岛湖",
            color: '#42A5F6'
         },
         {
            name: "稻城",
            color: '#5C6BC0'
         },
         {
            name: "大理",
            color: '#AA47BC'
         },
         {
            name: "丽江",
            color: '#EC407A'
         },

      ]
   },

   {
      id: 3,
      option: '早餐吃什么',
      awards: [
         {
            name: "包子",
            color: '#EE534F'
         },
         {
            name: "馒头",
            color: '#DA70D6'
         },
         {
            name: "粥",
            color: '#FFA827'
         },
         {
            name: "豆浆",
            color: '#5C6BC0'
         },
         {
            name: "油条",
            color: '#42A5F6'
         },
         {
            name: "鸡蛋",
            color: '#66BB6A'
         },
         {
            name: "面包",
            color: '#FFC928'
         },
         {
            name: "手抓饼",
            color: '#AA47BC'
         },
         {
            name: "肉夹馍",
            color: '#EC407A'
         },
         {
            name: "煎饼",
            color: '#FF7F50'
         }
      ]
   },
   {
      id: 4,
      option: '干饭人没烦恼',
      awards: [
         {
            name: "拉面",
            color: '#EE534F'
         },
         {
            name: "狗粮",
            color: '#AA47BC'
         },
         {
            name: "火锅",
            color: '#FFC928'
         },
         {
            name: "烧烤",
            color: '#66BB6A'
         },
         {
            name: "披萨",
            color: '#42A5F6'
         },
         {
            name: "烤鸭",
            color: '#5C6BC0'
         },
         {
            name: "牛排",
            color: '#EC407A'
         },
         {
            name: "汉堡",
            color: '#FF7F50'
         }
      ]
   },
   {
      id: 5,
      option: '中午吃什么',
      awards: [
         {
            name: "黄焖鸡米饭",
            color: '#FFA827'
         },
         {
            name: "拌面",
            color: '#AA47BC'
         },
         {
            name: "麦当劳",
            color: '#42A5F6'
         },
         {
            name: "寿司",
            color: '#00CED1'
         },
         {
            name: "蛋炒饭",
            color: '#66BB6A'
         },
         {
            name: "兰州拉面",
            color: '#FFC928'
         },
         {
            name: "沙县小吃",
            color: '#FFA500'
         },
         {
            name: "麻辣烫",
            color: '#FF4500'
         },
         {
            name: "老坛酸菜牛肉面",
            color: '#FFB6C1'
         }
      ]
   },
   {
      id: 6,
      option: '夜宵推荐',
      awards: [
         {
            index: 0,
            name: "烤串",
            color: '#EE534F'
         },
         {
            index: 1,
            name: "小龙虾",
            color: '#FF7F50'
         },
         {
            index: 2,
            name: "炸鸡",
            color: '#FFC928'
         },
         {
            index: 3,
            name: "空气",
            color: '#66BB6A'
         },
         {
            index: 4,
            name: "方便面",
            color: '#42A5F6'
         },
         {
            index: 5,
            name: "薯条",
            color: '#AA47BC'
         },
         {
            index: 6,
            name: "鸡排",
            color: '#EC407A'
         },
         {
            index: 7,
            name: "烤冷面",
            color: '#EE534F'
         },
         {
            index: 8,
            name: "炸串",
            color: '#FFC928'
         },
         {
            index: 9,
            name: "肯德基",
            color: '#66BB6A'
         },
         {
            index: 10,
            name: "水果",
            color: '#42A5F6'
         }
      ]
   },
 
   {
      id: 7,
      option: '下午茶',
      awards: [
         
         {
            name: "ladym",
            color: '#66BB6A'
         },
      
         {
            name: "星巴克",
            color: '#AA47BC'
         },
         {
            name: "喜茶",
            color: '#EC407A'
         },
         {
            name: "奈雪的茶",
            color: '#EE534F'
         },
         {
            name: "鲜芋仙",
            color: '#FFA827'
         },
        
         {
            name: "哈根达斯",
            color: '#42A5F6'
         },
         {
            name: "茶话弄",
            color: '#5C6BC0'
         }
      ]
   }
]