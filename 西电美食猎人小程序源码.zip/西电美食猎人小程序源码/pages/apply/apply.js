Page({
  data: {
    industryarr:[],
    industryindex:0,
    statusarr:[],
    statusindex:0,
    jobarr:[],
    jobindex:0,
    hasfinancing: false,  
    isorg: false,  
  },
  onLoad: function () {
    this.fetchData()
  },
  fetchData: function(){
    this.setData({
      industryarr:["请选择","西餐","中式","港式","台式","美式","法式","饮品","甜点","烘培","冰品","日式","快餐","自助","烧烤","轻食","创意","酒品","咖啡","其他"],
      statusarr:["请选择","奢华型","高挡型","平价型"],
      jobarr:["请选择","经理","主厨","二厨","收银员","服务员","工读","其他"]
    })
  },
  bindPickerChange: function(e){ //下拉选择
    const eindex = e.detail.value;
    const name = e.currentTarget.dataset.pickername;
    // this.setData(Object.assign({},this.data,{name:eindex}))
    switch(name) {
      case 'industry':
        this.setData({
          industryindex: eindex
        })
        break;
      case 'status':
        this.setData({
          statusindex: eindex
        })
        break;
      case 'job':
        this.setData({
          jobindex: eindex
        })
        break;
      default:
        return
    }
  },
  setFinance:function(e){ 
    this.setData({
      hasfinancing:e.detail.value=="已融资"?true:false
    })
  },
  setIsorg:function(e){ 
    this.setData({
      isorg:e.detail.value=="机构"?true:false
    })
  },
  applySubmit:function(){
    wx.navigateTo({
      url: '../index/index'
    })
  }
})
