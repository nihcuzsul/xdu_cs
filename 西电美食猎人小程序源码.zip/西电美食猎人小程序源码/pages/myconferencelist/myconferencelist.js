Page({
  data: {
    reservelist:[]
  },
  onLoad: function () {
    this.fetchData();
  },
  fetchData:function(){
    this.setData({
      reservelist:[
        {
          "id": 1,
          "name": "日记A01",
          "time": "2022/06/12 13:12",
          "reserver": "烤串",
          "imgurl": "https://img.zcool.cn/community/0120f65d08527fa801205e4bd99e69.jpg@1280w_1l_2o_100sh.jpg"
        },
        {
          "id": 2,
          "name": "日记B03",
          "time": "2022/06/11 18:49",
          "reserver": "酸辣粉",
          "imgurl": "https://img.zcool.cn/community/0132b05ba07c3ba801213deacb657c.jpg@1280w_1l_2o_100sh.jpg"
        },
        {
          "id": 3,
          "name": "日记B09",
          "time": "2022/06/11 14:05",
          "reserver": "Pizza",
          "imgurl": "https://img95.699pic.com/photo/50013/6758.jpg_wh860.jpg"
        },
        {
          "id": 4,
          "name": "日记B03",
          "time": "2022/05/30 11:30",
          "reserver": "海陆部队锅",
          "imgurl": "https://img.zcool.cn/community/0166615e2d7d9da80120a895f13dc0.jpg@1280w_1l_2o_100sh.jpg"
        },
        {
          "id": 5,
          "name": "日记B04",
          "time": "2022/05/30 11:23",
          "reserver": "螺蛳粉",
          "imgurl": "https://img.zcool.cn/community/01b3ff606c479411013e87f4c6da16.jpg@2o.jpg"
        },
        {
          "id": 6,
          "name": "日记A06",
          "time": "2022/05/25 13:00",
          "reserver": "烧烤BBQ",
          "imgurl": "https://tse4-mm.cn.bing.net/th/id/OIP-C.3ah1O18oc7BHiXPMFtRATQHaLH?pid=ImgDet&rs=1"
        },
         {
          "id": 8,
          "name": "日记A07",
          "time": "2022/05/25 11:43",
          "reserver": "寿司",
          "imgurl": "https://img.zcool.cn/community/01b2886090ee0011013e3b7de2d305.jpg@1280w_1l_2o_100sh.jpg"
        },{
          "id": 7,
          "name": "日记A08",
          "time": "2022/05/24 18:56",
          "reserver": "羊肋排",
          "imgurl": "https://img.zcool.cn/community/01512e5cb5571ca801208f8b302fc0.jpg@1280w_1l_2o_100sh.jpg"
        }

      ]
    })
  }
})
