Page({
  data: {
    checitems:[],
    // selected:null,
    selectedid: null
  },
  onLoad: function () {
    this.setData({
      checitems:[
        {
          "id":1,
          "text":"账号"
        },
        {
          "id":2,
          "text":"密码"
        },
        {
          "id":3,
          "text":"评论"
        },
        {
          "id":4,
          "text":"转盘"
        },
        {
          "id":5,
          "text":"日记"
        },
        {
          "id":6,
          "text":"注册"
        },
        {
          "id":7,
          "text":"页面显示"
        },
        {
          "id":8,
          "text":"收藏与分享"
        },
        {
          "id":9,
          "text":"输入"
        },
        {
          "id":10,
          "text":"图片上传"
        },
        {
          "id":11,
          "text":"其他"
        }
      ]
    })
  },
  onSelectTag: function(e){
    const eid = e.currentTarget.dataset.id;
    const selected = this.data.selected;
    this.setData({
      // selected:selected.indexOf(eid)>-1?selected.filter(i=>i!=eid):selected.concat(eid)
      selectedid:eid
    })
    console.log(this.data.selectedid);
  }
})
