Page({
    data: {
      reservelist:[]
    },
    onLoad: function () {
      this.fetchData();
    },
    fetchData:function(){
      this.setData({
        reservelist:[
          {
            "id": 1,
            "name": "猎人aslk**A01",
            "time": "5分",
            "reserver": "超级好吃",
            "imgurl": "http://1img.mgtv.com/preview/sp_images/2017/shenghuo/291200/3768921/20170105162653378.jpg"
          },
          {
            "id": 1,
            "name": "猎人aslk**A02",
            "time": "5分",
            "reserver": "好吃!!",
            "imgurl": "http://1img.mgtv.com/preview/sp_images/2017/shenghuo/291200/3768921/20170105162653378.jpg"
          },
          {
            "id": 1,
            "name": "猎人asxd**A03",
            "time": "5分",
            "reserver": "超级好吃!",
            "imgurl": "http://1img.mgtv.com/preview/sp_images/2017/shenghuo/291200/3768921/20170105162653378.jpg"
          },
          {
            "id": 1,
            "name": "猎人asxd**A04",
            "time": "5分",
            "reserver": "超级好吃!!",
            "imgurl": "http://1img.mgtv.com/preview/sp_images/2017/shenghuo/291200/3768921/20170105162653378.jpg"
          },
          {
            "id": 1,
            "name": "猎人aslk**A41",
            "time": "5分",
            "reserver": "超级好吃",
            "imgurl": "http://1img.mgtv.com/preview/sp_images/2017/shenghuo/291200/3768921/20170105162653378.jpg"
          },
          {
            "id": 1,
            "name": "猎人xdlk**A31",
            "time": "5分",
            "reserver": "好吃",
            "imgurl": "http://1img.mgtv.com/preview/sp_images/2017/shenghuo/291200/3768921/20170105162653378.jpg"
          },
          {
            "id": 1,
            "name": "猎人dslk**A22",
            "time": "5分",
            "reserver": "超级好",
            "imgurl": "http://1img.mgtv.com/preview/sp_images/2017/shenghuo/291200/3768921/20170105162653378.jpg"
          },
          {
            "id": 1,
            "name": "猎人asxk**A01",
            "time": "5分",
            "reserver": "好吃好吃",
            "imgurl": "http://1img.mgtv.com/preview/sp_images/2017/shenghuo/291200/3768921/20170105162653378.jpg"
          },
  
        ]
      })
    }
  })
  