//index.js
//获取应用实例
// var app = getApp();
Page({
  data: {
    indexmenu:[],
    imgUrls: []
  },
  onLoad:function(){
    //生命周期函数--监听页面加载
    this.fetchData();
    // var that = this
    // //调用应用实例的方法获取全局数据
    // app.getUserInfo(function(userInfo){
    //   //更新数据
    //   that.setData({
    //     userInfo:userInfo
    //   })
    // })
  },
  fetchData:function(){
    this.setData({
      indexmenu:[
        {
          'icon':'./../../images/ICON2.png',
          'text':'今日美食',
          'url':'space'
        },
        {
          'icon':'./../../images/ICON3.png',
          'text':'美食记录',
          'url':'service'
        },
        {
          'icon':'./../../images/ICON1.png',
          'text':'购物车',
          'url':'conference'
        },
        {
          'icon':'./../../images/ICON4.png',
          'text':'云资源',
          'url':'resource'
        },
        {
          'icon':'./../../images/ICON6.png',
          'text':'发表评论',
          'url':'question'
        },
        {
          'icon':'./../../images/ICON5.png',
          'text':'问题反馈',
          'url':'property'
        },
        {
          'icon':'./../../images/ICON7.png',
          'text':'注册申请',
          'url':'apply'
        }
      ],
      imgUrls: [
        'https://vthumb.ykimg.com/054101015EBCE9F38E182E959B6ED32C',
        'https://bksy.xidian.edu.cn/__local/4/02/AC/A78CE25E7729269BFC059F82FD6_C8F39145_2E5AF.jpg',
        'https://img.pic88.com/preview/2020/10/06/16019368935f7b9dfd40cd4.jpg!s640',
        
      ]
    })
  },
  changeRoute:function(url){
    wx.navigateTo({
      url: `../${url}/${url}`
    })
  },
  onReady:function(){
    //生命周期函数--监听页面初次渲染完成
    // console.log('onReady');
  },
  onShow :function(){
    //生命周期函数--监听页面显示
    // console.log('onShow');
  },
  onHide :function(){
    //生命周期函数--监听页面隐藏
    // console.log('onHide');
  },
  onUnload :function(){
    //生命周期函数--监听页面卸载
    // console.log('onUnload');
  },
  onPullDownRefresh:function(){
    //页面相关事件处理函数--监听用户下拉动作
    // console.log('onPullDownRefresh');
  },
  onReachBottom:function(){
    //页面上拉触底事件的处理函数
    // console.log('onReachBottom');
  }
})
