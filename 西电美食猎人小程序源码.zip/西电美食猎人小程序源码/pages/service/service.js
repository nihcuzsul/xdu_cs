Page({

    onLoad: function () { //加载数据渲染页面
    
      this.getDeviceoRecord();
    },
    onShow: function () {
      this.getDeviceoRecord();
    },
   
  
    getDeviceoRecord:function(){
      let that=this;
      wx.request({
        url: 'http://localhost:8091/wechadtCRUDfileupdownServlet_war_exploded/device_file_servlet_action?action=get_device_record&want_attachment=yes',
        data:{},
        header: { "content-type": "application/x-www-form-urlencoded", "x-requested-with": "XMLHttpRequest",},
        success:function(res){
          that.handlegetDeviceoRecord(res);
  
        },
        fail:function(res){
  
        }
      })
    },
    handlegetDeviceoRecord:function(res){
      console.log(JSON.stringify(res));
      this.setData({
        deviceList:res.data.aaData,//将表中查出来的信息传给devicelist
  
      });
  
    },
    onDeleteRecord:function(e){
      let that=this;
      console.log(JSON.stringify(e));
      wx.showModal({
        cancelColor: 'cancelColor',
        title:"提示",
        content:"您确认要删除该记录吗？",
        success: function (res) {
          if (res.confirm) {
            var id = e.currentTarget.dataset.itemid;
            console.log(id);
            wx.request({
              url: 'http://localhost:8091/wechadtCRUDfileupdownServlet_war_exploded/device_file_servlet_action?action=delete_device_record',
              data:{"id":id},
              header: { "content-type": "application/x-www-form-urlencoded", "x-requested-with": "XMLHttpRequest",},
              success:function(res){
                //that.handleDeleteTodoRecordResult(res);
                that.getDeviceoRecord();
              },
              fail:function(res){ 
              }
            })
          }
        }
      })
    },
    onModifyRecord:function(e){
      console.log(JSON.stringify(e));
      let that=this;
     /* var id = e.currentTarget.dataset.itemid;
      var title=e.currentTarget.dataset.itemtitle;
      var record=JSON.stringify({"id":id,"title":title});
      */
     wx.setStorageSync('item', e.currentTarget.dataset.item)
      wx.navigateTo({
        url: 'device/device_modify',
      })
    },
    onAddRecord:function(){
      wx.navigateTo({
        url: 'device/device_add',
      })
    }
  })