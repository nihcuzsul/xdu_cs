
var dateTimePicker = require('../../../utils/datetimePicker.js');
Page({
  data: {
    device_id: "",
    device_name:"",
    uploadimgs: [], //上传图片列表
    uploadAttachmentId: [],//上传图片返回id
    editable: false, //是否可编辑
    dateTime: null,
    dateTime1: null,
    dateTimeArray: [],
    dateTimeArray1: [],
    dateTimeStr: null,
  },
  onLoad: function (options) {
    
    var obj = dateTimePicker.dateTimePicker(this.data.startYear, this.data.endYear);
    var obj1 = dateTimePicker.dateTimePicker(this.data.startYear, this.data.endYear);
    
    var lastArray = obj1.dateTimeArray.pop();
    var lastTime = obj1.dateTime.pop();

    this.setData({
      dateTimeArray: obj.dateTimeArray,
      dateTimeArray1: obj1.dateTimeArray,
      dateTime: obj.dateTime,
      dateTime1: obj1.dateTime,
    })
  },
  inputDeviceID: function (e) {
    this.setData({
      device_id: e.detail.value,
    });
  },
  inputDeviceName: function (e) {
    this.setData({
      device_name: e.detail.value,
    });
  },
  chooseImage: function () {
    let _this = this;
    wx.showActionSheet({
      itemList: ['从相册中选择', '拍照'],
      itemColor: "#f7982a",
      success: function (res) {
        if (!res.cancel) {
          if (res.tapIndex == 0) {
            _this.chooseWxImage('album')
          } else if (res.tapIndex == 1) {
            _this.chooseWxImage('camera')
          }
        }
      }
    })
  },
  chooseWxImage: function (type) {
    let _this = this;
    wx.chooseImage({
      sizeType: ['original', 'compressed'],
      sourceType: [type],
      success: function (res) {
        _this.setData({
          uploadimgs: _this.data.uploadimgs.concat(res.tempFilePaths)
        });

        wx.uploadFile({
          filePath: res.tempFilePaths[0],
          name: "img",
          url: 'http://localhost:8091/wechadtCRUDfileupdownServlet_war_exploded/device_file_servlet_action?action=upload_device_record',
          header: { "content-type": "application/x-www-form-urlencoded", "x-requested-with": "XMLHttpRequest", },
          success: function (res) {//success会将返回的json字符串转换为json对象
            //微信小程序上传API接口wx.uploadFile的坑
            //返回的数据格式不是JSON格式（需要自己用JSON.parse()转化格式）
            //https://blog.csdn.net/Charles_Tian/article/details/80669530
            console.log(JSON.stringify(res.data));//stringify将对象转换为json字符串
            var data = JSON.parse(res.data);//因为返回的数据格式不是JSON格式（需要自己用JSON.parse()转化格式）转换为准确的对象格式
            _this.data.uploadAttachmentId.push(data.attachment_id);
            console.log(_this.data.uploadAttachmentId);
          },
          faile: function (res) {
            console.log(JSON.stringify(res));
          },
          complete: function (res) {
            console.log(JSON.stringify(res));
          }
        })
      }
    })
  },
  editImage: function () {
    this.setData({
      editable: !this.data.editable
    })
  },
  deleteImg: function (e) {
    console.log(e.currentTarget.dataset.index);
    const imgs = this.data.uploadimgs
    // Array.prototype.remove = function(i){
    //   const l = this.length;
    //   if(l==1){
    //     return []
    //   }else if(i>1){
    //     return [].concat(this.splice(0,i),this.splice(i+1,l-1))
    //   }
    // }
    this.setData({
      uploadimgs: imgs.remove(e.currentTarget.dataset.index)
    })
  },
  changeDateTime(e) {
    var dateTimeStr = this.getCurrentDateTime();
    console.log(dateTimeStr);
    this.setData({ dateTimeStr: dateTimeStr });
  },
  changeDateTimeColumn(e) {
    console.log(11);
    var arr = this.data.dateTime, dateArr = this.data.dateTimeArray;
    arr[e.detail.column] = e.detail.value;
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);
    this.setData({
      dateTimeArray: dateArr,
      dateTime: arr
    });
  },
  applySubmit: function () {
    if (this.checkInput()) {
      let that = this;
      var device_id = this.data.device_id;
      var device_name = this.data.device_name;
      console.log(this.data.uploadAttachmentId);
      wx.request({
             
        url: 'http://localhost:8091/wechadtCRUDfileupdownServlet_war_exploded/device_file_servlet_action?action=add_device_record',
        data: { "device_id": device_id,"device_name":device_name, "attachment_ids": that.data.uploadAttachmentId, "create_timee": that.getCurrentDateTime() },
        header: { "content-type": "application/x-www-form-urlencoded", "x-requested-with": "XMLHttpRequest", },
        success: function (res) {
          //that.handleAddTodoRecordResult(res);
          wx.showToast({
            title: '已经添加完毕！',
            icon: "none",
            duration: 2000,
            success: function (res) {
              setTimeout(function () {
                //要延时执行的代码
                wx.navigateBack({ delta: 1 });
              }, 2000) //延迟时间
            }
          })
        },
        fail: function (res) {
        }
      })
    }
  },
  checkInput:function(){
    var ok=true;
    if(this.data.device_id==undefined || this.data.device_id==null || this.data.device_id==""){
      wx.showToast({
        title: '请输入日记id！',
        icon:'none',
      })
      ok=false;
    }else if(this.data.device_name==undefined || this.data.device_name==null || this.data.device_name==""){
      wx.showToast({
        title: '请输入美食名称！',
        icon:'none',
      })
      ok=false;
    }
    return ok;
  },
  getCurrentDateTime: function () {
    var dateTimeStr = this.data.dateTimeArray[0][this.data.dateTime[0]] + "-" + this.data.dateTimeArray[1][this.data.dateTime[1]] + "-" + this.data.dateTimeArray[2][this.data.dateTime[2]];
    dateTimeStr = dateTimeStr + " " + this.data.dateTimeArray[3][this.data.dateTime[3]] + "-" + this.data.dateTimeArray[4][this.data.dateTime[4]] + "-" + this.data.dateTimeArray[5][this.data.dateTime[5]];
    return dateTimeStr;
  },
})

